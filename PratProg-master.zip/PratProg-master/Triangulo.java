
public class Triangulo extends Poligono {

	double ladoC;
	
	public Triangulo(double b, double a, double c) {
		super(b, a);
		this.ladoC = c;
	}

	@Override
	public double perimetro() {
		
		return 0;
	}

	@Override
	public double diagonal() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double volume() {
		// TODO Auto-generated method stub
		return 0;
	}

}


public abstract class Figura {
	
	public Figura() {
	}

	public abstract double area();
	public abstract double perimetro();
	public abstract double diagonal();
	public abstract double volume();
}